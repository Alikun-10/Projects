# Wordle_Java
The implementations is in Model.java and Wordle.java
First, have to enter your UserName.

![alt text](image-4.png)

Then you get directed to the main menu:

![alt text](image-9.png)

There is a few options there :

![alt text](image.png)
![alt text](image-2.png)
![alt text](image-3.png)

Then there's the select difficulty screen with a welcocme message.

![alt text](image-5.png)

Here is all the difficulties tested with a few different options.

![alt text](image-6.png)
![alt text](image-7.png)
![alt text](image-8.png)
